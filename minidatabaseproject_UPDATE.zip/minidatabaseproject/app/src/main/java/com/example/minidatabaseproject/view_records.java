package com.example.minidatabaseproject;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.LinkedList;

public class view_records extends AppCompatActivity {

    private LinkedList<Student> all_records;
    private final String db_name = "test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_records);
        setTitle("view all records");

        all_records = new LinkedList<>();

        SQLiteDatabase db = DB_config.openOrCreateDatabase(db_name,this);

        fetch_all_records(db);

    }

    private void fetch_all_records(SQLiteDatabase db)
    {
        all_records = DB_config.select_all_from_table(db,DB_config.SELECT_ALL_FROM_DATABASE);
        if(all_records==null)
            Toast.makeText(this, "no records to show", Toast.LENGTH_SHORT).show();

            //Toast.makeText(this, "the records are :: "+ all_records, Toast.LENGTH_SHORT).show();

       else{
            RecyclerView recycleV = findViewById(R.id.recyclerV);
            recycleV.setLayoutManager(new LinearLayoutManager(this));
            recycleV.setAdapter(new RecyclerAdapter(all_records,this));
        }
    }
}
