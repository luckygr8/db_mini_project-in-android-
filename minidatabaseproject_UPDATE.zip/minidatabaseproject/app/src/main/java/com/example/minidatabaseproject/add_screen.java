package com.example.minidatabaseproject;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class add_screen extends AppCompatActivity {

    private EditText ed_name;
    private EditText ed_rollnuber;

    private final String db_name = "test";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_screen);
        setTitle("add new record");
    }

    public void add_to_database(View view) {
        ed_name = findViewById(R.id.edittext_name);
        ed_rollnuber  = findViewById(R.id.edittext_rollnumber);

        if(!ed_name.getText().toString().equals("") && !ed_rollnuber.getText().toString().equals(""))
        {
            String name = ed_name.getText().toString();
            int rollnumber = Integer.parseInt(ed_rollnuber.getText().toString());

            Student record = new Student(name,rollnumber);

            SQLiteDatabase db = DB_config.openOrCreateDatabase(db_name,this);
            
            boolean result=DB_config.insert_into_table(record,db);
            
            if(result)
                Toast.makeText(this, "record was successfully added to database", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "could not add record to database", Toast.LENGTH_SHORT).show();
        }
        
        ed_name.setText("");
        ed_rollnuber.setText("");
    }
}
