package com.example.minidatabaseproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("database keeper");
    }

    public void add_new_record(View view) {
        Intent intent = new Intent(this,add_screen.class);
        startActivity(intent);
    }

    public void view_all_record(View view) {
        Intent intent = new Intent(this,view_records.class);
        startActivity(intent);
    }
}
