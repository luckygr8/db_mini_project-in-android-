package com.example.minidatabaseproject;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import java.util.LinkedList;

public class DB_config  {

    // strings declaration

    public static final String db_name = "test";
    private static final String TAG = "DB_configlog";
    public static final String SELECT_ALL_FROM_DATABASE = "SELECT * FROM studentinfo";
    public static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS studentinfo (_id INTEGER PRIMARY KEY AUTOINCREMENT , name TEXT , rollnumber INTEGER)";
    //

    public static SQLiteDatabase openOrCreateDatabase(String db_name, Context context)
    {
        SQLiteDatabase db = context.openOrCreateDatabase(db_name,Context.MODE_PRIVATE,null);
        return db;
    }
    public static boolean delete_from_database(SQLiteDatabase db , Student record)
    {
        String query = "DELETE FROM studentinfo where ";
        query+= " name = '"+record.getName()+"' and rollnumber = "+record.getRollnumber();
        Log.d(TAG, "delete_from_database: " + query);
        try{
            db.execSQL(query);
        }catch (Exception e){
            return false;
        }
        return true;
    }
    public static boolean insert_into_table(Student record , SQLiteDatabase db)
    {
        try
        {
            db.execSQL(CREATE_TABLE);
            Log.d(TAG, "insert_into_table: create table");
            String query = "INSERT INTO studentinfo(name,rollnumber) VALUES ";
            query+="('"+record.getName()+"',"+record.getRollnumber()+");";

            db.execSQL(query);
            Log.d(TAG, "insert_into_table: insertion done with query :: "+query);

        }catch(Exception e){
            Log.d(TAG, "insert_into_table: error ");
            return false;
        }
        return true;
    }

    public static LinkedList<Student> select_all_from_table(SQLiteDatabase db , String query)
    {
        LinkedList<Student> records = new LinkedList<>();
        Cursor c = db.rawQuery(query,null);

        int nameindex = c.getColumnIndex("name");
        int rollnumberindex = c.getColumnIndex("rollnumber");

        c.moveToFirst();

        if(c.getCount()==0)
        {
            Log.d(TAG, "select_from_table: records are not present");
            return null;
        }

        int count = 0;
        while(c!=null){
            Log.d(TAG, "===================================================");
            Log.d(TAG, "select_from_table: "+c.getString(nameindex));
            Log.d(TAG, "select_from_table: "+c.getInt(rollnumberindex));
            Log.d(TAG, "===================================================");

            records.add(new Student( c.getString(nameindex),c.getInt(rollnumberindex)));

            c.moveToNext();
            count++;
            if(count==c.getCount())
                break;
        }
        Log.d(TAG, "select_from_table: returning from viewall");
        return records;
    }
}
