package com.example.minidatabaseproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.Viewholder> {
    private Student curr_rec = new Student() ;
    private Context context;
    public RecyclerAdapter(LinkedList<Student> all_records , Context context) {
        this.all_records = all_records;
        this.context=context;
    }

    private LinkedList<Student> all_records;

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = LayoutInflater.from(viewGroup.getContext());
        View v =li.inflate(R.layout.recycler_layout,viewGroup,false);
        return new Viewholder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder viewholder, int i) {
        curr_rec = all_records.get(i);
        String str = " the name is :: " + curr_rec.getName()+"\n ";
        str+=" the roll number is :: " + Integer.toString(curr_rec.getRollnumber());
        viewholder.textView_record.setText(str);
        viewholder.rec.setName(curr_rec.getName());
        viewholder.rec.setRollnumber(curr_rec.getRollnumber());
        viewholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                viewholder.is_selected=true;
                int backgroundColor = ContextCompat.getColor(context, R.color.mybgcolor);
                viewholder.imgV_record.setVisibility(View.VISIBLE);
                v.setBackgroundColor(backgroundColor);
                return true;
            }
        });
        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewholder.is_selected){
                    int backgroundColor = ContextCompat.getColor(context, R.color.default_color);
                    viewholder.imgV_record.setVisibility(View.INVISIBLE);
                    viewholder.is_selected=false;
                    v.setBackgroundColor(backgroundColor);
                }
            }
        });


        viewholder.imgV_record.setOnClickListener(new View.OnClickListener() {
            /*
            * this method is used to delete a selected record from database
            * */
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = DB_config.openOrCreateDatabase(DB_config.db_name,context);
                boolean result = DB_config.delete_from_database(db,new Student(viewholder.rec.getName(),viewholder.rec.getRollnumber()));
                if(result){
                    Toast.makeText(context,"record was deleted",Toast.LENGTH_SHORT).show();
                    viewholder.linearL.setVisibility(View.GONE);
                }else
                    Toast.makeText(context, "could not delete the record", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return all_records.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder{

        TextView textView_record;
        Student rec;
        boolean is_selected;
        ImageView imgV_record;
        LinearLayout linearL;
        public Viewholder(@NonNull final View itemView) {
            super(itemView);
            rec = new Student();
            is_selected=false;
            linearL = itemView.findViewById(R.id.linearL);
            textView_record = itemView.findViewById(R.id.textview_record);
            imgV_record = itemView.findViewById(R.id.imgV_record);
        }
    }
}
