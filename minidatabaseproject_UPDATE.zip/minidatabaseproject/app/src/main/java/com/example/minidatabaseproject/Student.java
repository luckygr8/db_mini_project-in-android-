package com.example.minidatabaseproject;

public class Student {
    private String name;
    private int rollnumber;

    public Student(String name, int rollnumber) {
        this.name = name;
        this.rollnumber = rollnumber;
    }
    public Student(){

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRollnumber() {
        return rollnumber;
    }

    public void setRollnumber(int rollnumber) {
        this.rollnumber = rollnumber;
    }
}
